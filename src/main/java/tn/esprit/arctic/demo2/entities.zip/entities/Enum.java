package tn.esprit.arctic.demo2.entities;

public class Enum {
    public enum TypeMenu {
        PETIT_DEJEUNER,
        DEJEUNER,
        DINER
    }

    public enum TypeComposant {
        VIANDE_BLANCHE,
        VIANDE_ROUGE,
        CEREALE
    }

    public enum TypeChef {
        UNE_ETOILE,
        DEUX_ETOILES,
        TROIS_ETOILES
    }
}
